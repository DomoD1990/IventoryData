package com.example.inventorydata;

// 容器条目：从属空间 + 状态
public class ContainerItem extends BaseItem {
    private String belongSpaceId; // 从属空间ID
    private String status;        // 容器状态（可用/不可用等）

    // 空构造方法（必须保留，Gson反序列化需要）
    public ContainerItem() {
        super();
    }

    // 带参构造方法
    public ContainerItem(String id, String name, String belongSpaceId, String status) {
        super(id, name);
        this.belongSpaceId = belongSpaceId;
        this.status = status;
    }

    @Override
    public String getType() {
        return "容器";
    }

    // Getter & Setter
    public String getBelongSpaceId() {
        return belongSpaceId;
    }

    public void setBelongSpaceId(String belongSpaceId) {
        this.belongSpaceId = belongSpaceId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}