package com.example.inventorydata;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;

public class BaseItemTypeAdapter implements JsonSerializer<BaseItem>, JsonDeserializer<BaseItem> {
    private static final String TYPE_FIELD_NAME = "type";

    @Override
    public JsonElement serialize(BaseItem src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject jsonObject = context.serialize(src).getAsJsonObject();
        // 序列化时确保type字段存在（空值保护）
        if (src.getType() != null) {
            jsonObject.addProperty(TYPE_FIELD_NAME, src.getType());
        } else {
            jsonObject.addProperty(TYPE_FIELD_NAME, "未知"); // 兜底值
        }
        return jsonObject;
    }

    @Override
    public BaseItem deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        JsonObject jsonObject = json.getAsJsonObject();

        // 核心修复：空值校验 + 兜底处理
        JsonElement typeElement = jsonObject.get(TYPE_FIELD_NAME);
        String type = null;
        if (typeElement != null && !typeElement.isJsonNull()) {
            type = typeElement.getAsString();
        }

        // 类型为空时的兜底逻辑
        if (type == null || type.isEmpty()) {
            // 尝试从字段特征判断类型（兼容旧数据）
            if (jsonObject.has("address")) {
                type = "地点";
            } else if (jsonObject.has("belongLocationId")) {
                type = "空间";
            } else if (jsonObject.has("belongSpaceId") && jsonObject.has("status") && !jsonObject.has("quantity")) {
                // 区分设备和容器：设备/容器有status，物品有quantity
                if (jsonObject.has("belongContainerId")) {
                    type = "物品";
                } else {
                    // 优先判断为设备（也可根据业务调整）
                    type = "设备";
                }
            } else if (jsonObject.has("belongContainerId") && jsonObject.has("quantity")) {
                type = "物品";
            } else {
                type = "未知"; // 最终兜底
            }
        }

        // 根据类型反序列化为对应子类
        switch (type) {
            case "地点":
                return context.deserialize(jsonObject, LocationItem.class);
            case "空间":
                return context.deserialize(jsonObject, SpaceItem.class);
            case "设备":
                return context.deserialize(jsonObject, DeviceItem.class);
            case "容器":
                return context.deserialize(jsonObject, ContainerItem.class);
            case "物品":
                return context.deserialize(jsonObject, Item.class);
            default:
                // 未知类型时返回BaseItem（避免崩溃）
                return context.deserialize(jsonObject, BaseItem.class);
        }
    }
}