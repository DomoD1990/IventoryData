package com.example.inventorydata;

// 设备条目：从属空间 + 状态
public class DeviceItem extends BaseItem {
    private String belongSpaceId; // 从属空间ID
    private String status;        // 设备状态（正常/故障/维修等）

    // 空构造方法（必须保留，Gson反序列化需要）
    public DeviceItem() {
        super();
    }

    // 带参构造方法
    public DeviceItem(String id, String name, String belongSpaceId, String status) {
        super(id, name);
        this.belongSpaceId = belongSpaceId;
        this.status = status;
    }

    @Override
    public String getType() {
        return "设备";
    }

    // Getter & Setter
    public String getBelongSpaceId() {
        return belongSpaceId;
    }

    public void setBelongSpaceId(String belongSpaceId) {
        this.belongSpaceId = belongSpaceId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}