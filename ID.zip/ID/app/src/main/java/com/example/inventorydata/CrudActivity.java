package com.example.inventorydata;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class CrudActivity extends AppCompatActivity {
    private static final String TAG = "CrudActivity";
    private static final int REQUEST_CAMERA = 1;
    private static final int REQUEST_GALLERY = 2;
    private static final int PERMISSION_REQUEST_CAMERA = 101;
    private static final int PERMISSION_REQUEST_STORAGE = 102;

    private Spinner spinnerItemType;
    private LinearLayout llFormContainer;
    private ImageView ivSelectedImage;
    private String selectedImagePath;
    private DataManager dataManager;
    private String currentItemId;
    private BaseItem currentEditingItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crud);

        // 初始化控件
        spinnerItemType = findViewById(R.id.spinner_item_type);
        llFormContainer = findViewById(R.id.ll_form_container);
        ivSelectedImage = findViewById(R.id.iv_selected_image);
        Button btnSelectImage = findViewById(R.id.btn_select_image);
        Button btnDelete = findViewById(R.id.btn_delete);
        Button btnSave = findViewById(R.id.btn_save);

        dataManager = DataManager.getInstance(this);
        currentItemId = getIntent().getStringExtra("ITEM_ID");

        // 设置图片显示控件
        ivSelectedImage.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                400
        ));
        ivSelectedImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ivSelectedImage.setBackgroundColor(ContextCompat.getColor(this, R.color.neon_green));
        ivSelectedImage.setPadding(8, 8, 8, 8);

        // 条目类型选择监听
        spinnerItemType.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                String selectedType = parent.getSelectedItem().toString();
                generateForm(selectedType);
                if (currentEditingItem != null) {
                    safeLoadItemData(currentEditingItem);
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        // 图片选择按钮
        btnSelectImage.setOnClickListener(v -> showImageSelectDialog());

        // 删除按钮
        btnDelete.setOnClickListener(v -> {
            if (currentItemId == null) {
                Toast.makeText(this, "无条目可删除", Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("确认删除")
                    .setMessage("是否删除该条目？")
                    .setPositiveButton("是", (dialog, which) -> {
                        // 删除条目时同时删除图片文件（可选）
                        if (currentEditingItem != null && currentEditingItem.getImagePath() != null) {
                            deleteImageFile(currentEditingItem.getImagePath());
                        }
                        dataManager.deleteItem(currentItemId);
                        Toast.makeText(CrudActivity.this, "删除成功", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .setNegativeButton("否", null)
                    .show();
        });

        // 保存按钮
        btnSave.setOnClickListener(v -> saveItem());

        // 编辑模式：加载条目数据
        if (currentItemId != null) {
            currentEditingItem = dataManager.getItemById(currentItemId);
            if (currentEditingItem == null) {
                Toast.makeText(this, "条目数据不存在", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // 1. 先加载图片（核心修复：优先读取持久化的图片路径）
            selectedImagePath = currentEditingItem.getImagePath();
            Log.d(TAG, "加载条目图片路径：" + selectedImagePath);
            loadItemImage(selectedImagePath);

            // 2. 设置类型选择
            String[] types = getResources().getStringArray(R.array.item_types);
            for (int i = 0; i < types.length; i++) {
                if (types[i].equals(currentEditingItem.getType())) {
                    spinnerItemType.setSelection(i);
                    break;
                }
            }
        } else {
            // 新增模式：默认生成地点表单
            generateForm("地点");
            // 显示默认占位图
            ivSelectedImage.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }

    // 修复：加载图片（添加详细日志和容错）
    private void loadItemImage(String imagePath) {
        if (imagePath == null || imagePath.isEmpty()) {
            Log.d(TAG, "图片路径为空，显示占位图");
            ivSelectedImage.setImageResource(android.R.drawable.ic_menu_gallery);
            return;
        }

        File imageFile = new File(imagePath);
        if (imageFile.exists() && imageFile.length() > 0) {
            try {
                // 优化：解码图片时避免OOM
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 2; // 缩小图片，根据需求调整
                Bitmap bitmap = BitmapFactory.decodeFile(imagePath, options);
                if (bitmap != null) {
                    ivSelectedImage.setImageBitmap(bitmap);
                    Log.d(TAG, "图片加载成功：" + imagePath);
                } else {
                    Log.e(TAG, "图片解码失败：" + imagePath);
                    ivSelectedImage.setImageResource(android.R.drawable.ic_menu_gallery);
                }
            } catch (Exception e) {
                Log.e(TAG, "加载图片异常：" + e.getMessage());
                ivSelectedImage.setImageResource(android.R.drawable.ic_menu_gallery);
            }
        } else {
            Log.e(TAG, "图片文件不存在或为空：" + imagePath);
            ivSelectedImage.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }

    // 修复：保存图片到本地（确保路径正确）
    private String saveBitmapToFile(Bitmap bitmap) {
        if (bitmap == null) {
            Log.e(TAG, "保存图片失败：bitmap为空");
            return null;
        }

        try {
            // 使用应用私有目录，避免权限问题（核心修复）
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "InventoryData");
            if (!dir.exists()) {
                dir.mkdirs();
                Log.d(TAG, "创建图片目录：" + dir.getAbsolutePath());
            }

            String fileName = UUID.randomUUID().toString() + ".png";
            File file = new File(dir, fileName);

            try (FileOutputStream fos = new FileOutputStream(file)) {
                boolean saveSuccess = bitmap.compress(Bitmap.CompressFormat.PNG, 90, fos);
                if (saveSuccess) {
                    String absolutePath = file.getAbsolutePath();
                    Log.d(TAG, "图片保存成功：" + absolutePath);
                    return absolutePath;
                } else {
                    Log.e(TAG, "图片压缩失败");
                    return null;
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "保存图片异常：" + e.getMessage());
            return null;
        }
    }

    // 修复：处理图片选择结果（优化相册图片读取）
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            try {
                Bitmap bitmap = null;
                if (requestCode == REQUEST_CAMERA) {
                    // 拍照结果
                    bitmap = (Bitmap) data.getExtras().get("data");
                } else if (requestCode == REQUEST_GALLERY) {
                    // 相册结果（优化：通过ContentResolver读取）
                    Uri uri = data.getData();
                    ParcelFileDescriptor parcelFileDescriptor = getContentResolver().openFileDescriptor(uri, "r");
                    FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                    bitmap = BitmapFactory.decodeFileDescriptor(fileDescriptor);
                    parcelFileDescriptor.close();
                }

                if (bitmap != null) {
                    // 保存图片并更新路径
                    selectedImagePath = saveBitmapToFile(bitmap);
                    // 立即显示图片
                    ivSelectedImage.setImageBitmap(bitmap);
                    Toast.makeText(this, "图片选择成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "图片读取失败", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Log.e(TAG, "处理图片结果异常：" + e.getMessage());
                Toast.makeText(this, "图片处理失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    // 修复：保存条目（确保imagePath正确赋值）
    private void saveItem() {
        String itemType = spinnerItemType.getSelectedItem().toString();
        BaseItem item = null;

        // 获取名称
        EditText etName = findViewByTag("name");
        if (etName == null) {
            Toast.makeText(this, "表单加载异常", Toast.LENGTH_SHORT).show();
            return;
        }
        String name = etName.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, "名称为必填项", Toast.LENGTH_SHORT).show();
            return;
        }

        // 根据类型创建条目
        switch (itemType) {
            case "地点":
                EditText etAddress = findViewByTag("address");
                String address = etAddress != null ? etAddress.getText().toString().trim() : "";
                item = new LocationItem(
                        currentItemId == null ? UUID.randomUUID().toString() : currentItemId,
                        name,
                        address
                );
                break;
            case "空间":
                Spinner spBelongLocation = findViewByTag("belongLocation");
                if (spBelongLocation == null || spBelongLocation.getSelectedItemPosition() < 0) {
                    Toast.makeText(this, "请先创建地点，再选择从属地点", Toast.LENGTH_SHORT).show();
                    return;
                }
                List<BaseItem> locations = dataManager.getItemsByType("地点");
                String belongLocationId = locations.get(spBelongLocation.getSelectedItemPosition()).getId();
                item = new SpaceItem(
                        currentItemId == null ? UUID.randomUUID().toString() : currentItemId,
                        name,
                        belongLocationId
                );
                break;
            case "设备":
                Spinner spBelongSpace = findViewByTag("belongSpace");
                if (spBelongSpace == null || spBelongSpace.getSelectedItemPosition() < 0) {
                    Toast.makeText(this, "请先创建空间，再选择从属空间", Toast.LENGTH_SHORT).show();
                    return;
                }
                List<BaseItem> spaces = dataManager.getItemsByType("空间");
                String belongSpaceId = spaces.get(spBelongSpace.getSelectedItemPosition()).getId();
                EditText etStatus = findViewByTag("status");
                String status = etStatus != null ? etStatus.getText().toString().trim() : "";
                item = new DeviceItem(
                        currentItemId == null ? UUID.randomUUID().toString() : currentItemId,
                        name,
                        belongSpaceId,
                        status
                );
                break;
            case "容器":
                Spinner spBelongSpace2 = findViewByTag("belongSpace");
                if (spBelongSpace2 == null || spBelongSpace2.getSelectedItemPosition() < 0) {
                    Toast.makeText(this, "请先创建空间，再选择从属空间", Toast.LENGTH_SHORT).show();
                    return;
                }
                List<BaseItem> spaces2 = dataManager.getItemsByType("空间");
                String belongSpaceId2 = spaces2.get(spBelongSpace2.getSelectedItemPosition()).getId();
                EditText etStatus2 = findViewByTag("status");
                String status2 = etStatus2 != null ? etStatus2.getText().toString().trim() : "";
                item = new ContainerItem(
                        currentItemId == null ? UUID.randomUUID().toString() : currentItemId,
                        name,
                        belongSpaceId2,
                        status2
                );
                break;
            case "物品":
                Spinner spBelongContainer = findViewByTag("belongContainer");
                if (spBelongContainer == null || spBelongContainer.getSelectedItemPosition() < 0) {
                    Toast.makeText(this, "请先创建容器，再选择从属容器", Toast.LENGTH_SHORT).show();
                    return;
                }
                List<BaseItem> containers = dataManager.getItemsByType("容器");
                String belongContainerId = containers.get(spBelongContainer.getSelectedItemPosition()).getId();
                EditText etQuantity = findViewByTag("quantity");
                String quantityStr = etQuantity != null ? etQuantity.getText().toString().trim() : "";
                if (quantityStr.isEmpty()) {
                    Toast.makeText(this, "数量为必填项", Toast.LENGTH_SHORT).show();
                    return;
                }
                int quantity;
                try {
                    quantity = Integer.parseInt(quantityStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "数量必须为数字", Toast.LENGTH_SHORT).show();
                    return;
                }
                EditText etExpire = findViewByTag("expirationDate");
                String expirationDate = etExpire != null ? etExpire.getText().toString().trim() : "";
                item = new Item(
                        currentItemId == null ? UUID.randomUUID().toString() : currentItemId,
                        name,
                        belongContainerId,
                        quantity,
                        expirationDate
                );
                break;
        }

        if (item == null) {
            Toast.makeText(this, "条目创建失败", Toast.LENGTH_SHORT).show();
            return;
        }

        // 核心修复：强制赋值图片路径（确保不会丢失）
        item.setImagePath(selectedImagePath);
        Log.d(TAG, "保存条目图片路径：" + selectedImagePath);

        // 设置其他字段
        EditText etTags = findViewByTag("tags");
        item.setTags(etTags != null ? etTags.getText().toString().trim() : "");
        EditText etRemark = findViewByTag("remark");
        item.setRemark(etRemark != null ? etRemark.getText().toString().trim() : "");

        // 保存/更新条目
        if (currentItemId == null) {
            dataManager.addItem(item);
            Toast.makeText(this, "新增成功", Toast.LENGTH_SHORT).show();
        } else {
            // 更新前删除旧图片（可选）
            if (currentEditingItem != null && currentEditingItem.getImagePath() != null
                    && !currentEditingItem.getImagePath().equals(selectedImagePath)) {
                deleteImageFile(currentEditingItem.getImagePath());
            }
            dataManager.updateItem(item);
            Toast.makeText(this, "修改成功", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    // 辅助：删除图片文件
    private void deleteImageFile(String path) {
        if (path == null || path.isEmpty()) return;
        File file = new File(path);
        if (file.exists()) {
            boolean deleted = file.delete();
            Log.d(TAG, "删除图片文件：" + path + " 结果：" + deleted);
        }
    }

    // 安全加载条目数据
    private void safeLoadItemData(BaseItem item) {
        if (item == null) return;

        // 填充通用字段
        setEditTextValue("name", item.getName());
        setEditTextValue("tags", item.getTags());
        setEditTextValue("remark", item.getRemark());

        // 核心：重新加载图片（确保最新）
        loadItemImage(item.getImagePath());

        String itemType = item.getType();
        switch (itemType) {
            case "地点":
                if (item instanceof LocationItem) {
                    LocationItem location = (LocationItem) item;
                    setEditTextValue("address", location.getAddress());
                } else {
                    Toast.makeText(this, "数据类型异常，已加载基础信息", Toast.LENGTH_SHORT).show();
                }
                break;
            case "空间":
                Spinner spLocation = findViewByTag("belongLocation");
                if (spLocation != null && item instanceof SpaceItem) {
                    SpaceItem space = (SpaceItem) item;
                    selectSpinnerItem(spLocation, space.getBelongLocationId(), dataManager.getItemsByType("地点"));
                } else {
                    Toast.makeText(this, "数据类型异常，已加载基础信息", Toast.LENGTH_SHORT).show();
                }
                break;
            case "设备":
                Spinner spSpace = findViewByTag("belongSpace");
                if (spSpace != null && item instanceof DeviceItem) {
                    DeviceItem device = (DeviceItem) item;
                    setEditTextValue("status", device.getStatus());
                    selectSpinnerItem(spSpace, device.getBelongSpaceId(), dataManager.getItemsByType("空间"));
                } else {
                    Toast.makeText(this, "数据类型异常，已加载基础信息", Toast.LENGTH_SHORT).show();
                }
                break;
            case "容器":
                Spinner spSpace2 = findViewByTag("belongSpace");
                if (spSpace2 != null && item instanceof ContainerItem) {
                    ContainerItem container = (ContainerItem) item;
                    setEditTextValue("status", container.getStatus());
                    selectSpinnerItem(spSpace2, container.getBelongSpaceId(), dataManager.getItemsByType("空间"));
                } else {
                    Toast.makeText(this, "数据类型异常，已加载基础信息", Toast.LENGTH_SHORT).show();
                }
                break;
            case "物品":
                Spinner spContainer = findViewByTag("belongContainer");
                if (spContainer != null && item instanceof Item) {
                    Item itemObj = (Item) item;
                    setEditTextValue("quantity", String.valueOf(itemObj.getQuantity()));
                    setEditTextValue("expirationDate", itemObj.getExpirationDate());
                    selectSpinnerItem(spContainer, itemObj.getBelongContainerId(), dataManager.getItemsByType("容器"));
                } else {
                    Toast.makeText(this, "数据类型异常，已加载基础信息", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    // 其他原有方法（保持不变）
    private void showImageSelectDialog() {
        new AlertDialog.Builder(this)
                .setTitle("选择图片来源")
                .setItems(new String[]{"拍照", "相册"}, (dialog, which) -> {
                    if (which == 0) {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                                != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(
                                    this,
                                    new String[]{Manifest.permission.CAMERA},
                                    PERMISSION_REQUEST_CAMERA
                            );
                        } else {
                            openCamera();
                        }
                    } else {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                                != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(
                                    this,
                                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                                    PERMISSION_REQUEST_STORAGE
                            );
                        } else {
                            openGallery();
                        }
                    }
                })
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            switch (requestCode) {
                case PERMISSION_REQUEST_CAMERA:
                    openCamera();
                    break;
                case PERMISSION_REQUEST_STORAGE:
                    openGallery();
                    break;
            }
        } else {
            Toast.makeText(this, "权限被拒绝，无法使用该功能", Toast.LENGTH_SHORT).show();
        }
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, REQUEST_CAMERA);
    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, REQUEST_GALLERY);
    }

    private void generateForm(String itemType) {
        llFormContainer.removeAllViews();
        addEditText("名称（必填）", "name", true);

        switch (itemType) {
            case "地点":
                addEditText("地址", "address", false);
                break;
            case "空间":
                addSpinner("从属地点（必填）", "belongLocation", dataManager.getItemsByType("地点"));
                break;
            case "设备":
                addSpinner("从属空间（必填）", "belongSpace", dataManager.getItemsByType("空间"));
                addEditText("状态", "status", false);
                break;
            case "容器":
                addSpinner("从属空间（必填）", "belongSpace", dataManager.getItemsByType("空间"));
                addEditText("状态", "status", false);
                break;
            case "物品":
                addSpinner("从属容器（必填）", "belongContainer", dataManager.getItemsByType("容器"));
                addEditText("数量（必填）", "quantity", true);
                addEditText("保质期", "expirationDate", false);
                break;
        }

        addEditText("标签", "tags", false);
        addEditText("备注", "remark", false);
    }

    private void addEditText(String hint, String tag, boolean required) {
        EditText editText = new EditText(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 8);
        editText.setLayoutParams(params);
        editText.setHint(hint + (required ? " *" : ""));
        editText.setTag(tag);
        editText.setBackgroundColor(ContextCompat.getColor(this, R.color.neon_green));
        editText.setTextColor(ContextCompat.getColor(this, R.color.black));
        editText.setTextSize(16);
        editText.setPadding(8, 8, 8, 8);
        llFormContainer.addView(editText);
    }

    private void addSpinner(String hint, String tag, List<BaseItem> data) {
        if (data.isEmpty()) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));
            tvEmpty.setText(hint + "：暂无可用数据，请先创建");
            tvEmpty.setTextColor(ContextCompat.getColor(this, R.color.black));
            tvEmpty.setTextSize(16);
            llFormContainer.addView(tvEmpty);
            return;
        }

        TextView tvHint = new TextView(this);
        LinearLayout.LayoutParams tvParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        tvParams.setMargins(0, 0, 0, 4);
        tvHint.setLayoutParams(tvParams);
        tvHint.setText(hint);
        tvHint.setTextColor(ContextCompat.getColor(this, R.color.black));
        tvHint.setTextSize(16);
        llFormContainer.addView(tvHint);

        Spinner spinner = new Spinner(this);
        LinearLayout.LayoutParams spParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        spParams.setMargins(0, 0, 0, 8);
        spinner.setLayoutParams(spParams);
        spinner.setTag(tag);
        spinner.setBackgroundColor(ContextCompat.getColor(this, R.color.neon_green));

        String[] itemNames = new String[data.size()];
        for (int i = 0; i < data.size(); i++) {
            itemNames[i] = data.get(i).getName();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, itemNames) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setTextColor(ContextCompat.getColor(CrudActivity.this, R.color.black));
                textView.setTextSize(16);
                return view;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setTextColor(ContextCompat.getColor(CrudActivity.this, R.color.black));
                textView.setBackgroundColor(ContextCompat.getColor(CrudActivity.this, R.color.neon_green));
                textView.setTextSize(16);
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        llFormContainer.addView(spinner);
    }

    private void selectSpinnerItem(Spinner spinner, String targetId, List<BaseItem> dataList) {
        if (spinner == null || targetId == null || dataList.isEmpty()) return;
        for (int i = 0; i < dataList.size(); i++) {
            if (dataList.get(i).getId().equals(targetId)) {
                spinner.setSelection(i);
                break;
            }
        }
    }

    private <T extends View> T findViewByTag(String tag) {
        for (int i = 0; i < llFormContainer.getChildCount(); i++) {
            View view = llFormContainer.getChildAt(i);
            if (tag.equals(view.getTag())) {
                return (T) view;
            }
        }
        return null;
    }

    private void setEditTextValue(String tag, String value) {
        EditText et = findViewByTag(tag);
        if (et != null && value != null) {
            et.setText(value);
        }
    }
}