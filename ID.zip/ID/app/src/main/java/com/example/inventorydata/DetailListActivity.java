package com.example.inventorydata;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.SimpleExpandableListAdapter;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DetailListActivity extends AppCompatActivity {
    private ExpandableListView elvDetailList;
    private DataManager dataManager;
    // 存储所有条目（用于点击匹配）
    private Map<String, BaseItem> itemIdMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_list);

        elvDetailList = findViewById(R.id.elv_detail_list);
        Button btnImport = findViewById(R.id.btn_import);
        Button btnExport = findViewById(R.id.btn_export);

        dataManager = DataManager.getInstance(this);
        itemIdMap = new HashMap<>(); // 初始化ID映射

        // 加载详细列表
        loadDetailList();

        // 添加条目点击监听（核心新增）
        elvDetailList.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                // 获取点击的条目ID
                String itemId = getChildItemId(groupPosition, childPosition);
                if (itemId != null) {
                    // 跳转到CrudActivity并传递条目ID
                    Intent intent = new Intent(DetailListActivity.this, CrudActivity.class);
                    intent.putExtra("ITEM_ID", itemId);
                    startActivity(intent);
                } else {
                    Toast.makeText(DetailListActivity.this, "条目数据异常", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        // 导入按钮
        btnImport.setOnClickListener(v -> {
            Toast.makeText(this, "导入功能待实现", Toast.LENGTH_SHORT).show();
        });

        // 导出按钮
        btnExport.setOnClickListener(v -> {
            Toast.makeText(this, "导出功能待实现", Toast.LENGTH_SHORT).show();
        });
    }

    // 加载详细列表（新增ID映射）
    private void loadDetailList() {
        List<BaseItem> allItems = dataManager.getAllItems();
        if (allItems.isEmpty()) {
            Toast.makeText(this, "暂无数据，请先创建条目", Toast.LENGTH_SHORT).show();
            return;
        }

        // 清空ID映射
        itemIdMap.clear();

        // 分组数据：按类型分组
        Map<String, List<BaseItem>> groupedItems = new HashMap<>();
        List<String> typeOrder = new ArrayList<>(); // 记录分组顺序
        for (BaseItem item : allItems) {
            String type = item.getType();
            if (!groupedItems.containsKey(type)) {
                groupedItems.put(type, new ArrayList<>());
                typeOrder.add(type);
            }
            groupedItems.get(type).add(item);
            // 存储ID映射
            itemIdMap.put(type + "_" + groupedItems.get(type).size(), item);
        }

        // 准备ExpandableListView数据
        List<Map<String, String>> groupData = new ArrayList<>();
        List<List<Map<String, String>>> childData = new ArrayList<>();

        // 填充分组和子项
        for (String type : typeOrder) {
            List<BaseItem> items = groupedItems.get(type);
            // 分组数据
            Map<String, String> groupMap = new HashMap<>();
            groupMap.put("type", type + "（共" + items.size() + "条）");
            groupData.add(groupMap);

            // 子项数据
            List<Map<String, String>> childList = new ArrayList<>();
            for (int i = 0; i < items.size(); i++) {
                BaseItem item = items.get(i);
                // 存储条目ID到映射（key格式：类型_索引）
                itemIdMap.put(type + "_" + (i+1), item);

                Map<String, String> childMap = new HashMap<>();
                childMap.put("name", item.getName());
                // 按类型显示特有信息
                switch (type) {
                    case "地点":
                        LocationItem location = (LocationItem) item;
                        childMap.put("detail", "地址：" + location.getAddress());
                        break;
                    case "空间":
                        SpaceItem space = (SpaceItem) item;
                        BaseItem belongLocation = dataManager.getItemById(space.getBelongLocationId());
                        childMap.put("detail", "从属地点：" + (belongLocation != null ? belongLocation.getName() : "未知"));
                        break;
                    case "设备":
                        DeviceItem device = (DeviceItem) item;
                        BaseItem belongSpace = dataManager.getItemById(device.getBelongSpaceId());
                        childMap.put("detail", "从属空间：" + (belongSpace != null ? belongSpace.getName() : "未知") + " | 状态：" + device.getStatus());
                        break;
                    case "容器":
                        ContainerItem container = (ContainerItem) item;
                        BaseItem belongSpace2 = dataManager.getItemById(container.getBelongSpaceId());
                        childMap.put("detail", "从属空间：" + (belongSpace2 != null ? belongSpace2.getName() : "未知") + " | 状态：" + container.getStatus());
                        break;
                    case "物品":
                        Item itemObj = (Item) item;
                        BaseItem belongContainer = dataManager.getItemById(itemObj.getBelongContainerId());
                        childMap.put("detail", "从属容器：" + (belongContainer != null ? belongContainer.getName() : "未知") + " | 数量：" + itemObj.getQuantity());
                        break;
                }
                childList.add(childMap);
            }
            childData.add(childList);
        }

        // 创建适配器
        SimpleExpandableListAdapter adapter = new SimpleExpandableListAdapter(
                this,
                groupData,
                android.R.layout.simple_expandable_list_item_1,
                new String[]{"type"},
                new int[]{android.R.id.text1},
                childData,
                android.R.layout.simple_expandable_list_item_2,
                new String[]{"name", "detail"},
                new int[]{android.R.id.text1, android.R.id.text2}
        );

        elvDetailList.setAdapter(adapter);
    }

    // 新增：根据分组和子项位置获取条目ID
    private String getChildItemId(int groupPosition, int childPosition) {
        List<BaseItem> allItems = dataManager.getAllItems();
        Map<String, List<BaseItem>> groupedItems = new HashMap<>();
        List<String> typeOrder = new ArrayList<>();

        // 重建分组顺序
        for (BaseItem item : allItems) {
            String type = item.getType();
            if (!groupedItems.containsKey(type)) {
                groupedItems.put(type, new ArrayList<>());
                typeOrder.add(type);
            }
            groupedItems.get(type).add(item);
        }

        // 获取对应类型和条目
        if (groupPosition < typeOrder.size()) {
            String type = typeOrder.get(groupPosition);
            List<BaseItem> items = groupedItems.get(type);
            if (childPosition < items.size()) {
                return items.get(childPosition).getId();
            }
        }
        return null;
    }
}