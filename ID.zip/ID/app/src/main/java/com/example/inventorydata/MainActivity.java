package com.example.inventorydata;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText etSearch;
    private ListView lvSearchResult;
    private DataManager dataManager;
    private List<BaseItem> currentSearchResults; // 存储完整的搜索结果对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化控件
        etSearch = findViewById(R.id.et_search);
        lvSearchResult = findViewById(R.id.lv_search_result);
        Button btnSearch = findViewById(R.id.btn_search);
        Button btnCrud = findViewById(R.id.btn_crud);
        Button btnDetailList = findViewById(R.id.btn_detail_list);

        // 初始化数据管理器
        dataManager = DataManager.getInstance(this);

        // 搜索按钮点击事件
        btnSearch.setOnClickListener(v -> {
            String keyword = etSearch.getText().toString().trim();
            currentSearchResults = dataManager.searchItems(keyword);
            updateSearchResultList(currentSearchResults);
        });

        // 列表点击事件：跳转到增删改查页面（修复类型转换问题）
        lvSearchResult.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (currentSearchResults != null && position < currentSearchResults.size()) {
                    BaseItem selectedItem = currentSearchResults.get(position);
                    Intent intent = new Intent(MainActivity.this, CrudActivity.class);
                    intent.putExtra("ITEM_ID", selectedItem.getId());
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "暂无该条目数据", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 增删改查按钮：跳转到CrudActivity
        btnCrud.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CrudActivity.class);
            startActivity(intent);
        });

        // 详细列表按钮：跳转到DetailListActivity
        btnDetailList.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DetailListActivity.class);
            startActivity(intent);
        });
    }

    // 更新搜索结果列表（修复：存储完整对象，仅展示名称）
    private void updateSearchResultList(List<BaseItem> items) {
        currentSearchResults = items;
        // 提取条目名称用于展示
        String[] itemNames = new String[items.size()];
        for (int i = 0; i < items.size(); i++) {
            itemNames[i] = items.get(i).getType() + "：" + items.get(i).getName();
        }
        ArrayAdapter<String> searchAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                itemNames
        );
        lvSearchResult.setAdapter(searchAdapter);
    }
}