package com.example.inventorydata;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast; // 导入Toast类
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DataManager {
    private static final String PREF_NAME = "InventoryDataPrefs";
    private static final String KEY_ALL_ITEMS = "all_items";
    private static DataManager instance;
    private final SharedPreferences sharedPreferences;
    private final Gson gson;
    private final Context appContext; // 新增：保存应用上下文
    private List<BaseItem> allItems;

    private DataManager(Context context) {
        // 保存应用上下文（避免内存泄漏）
        appContext = context.getApplicationContext();
        sharedPreferences = appContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        // 关键：添加类型适配器，保留子类信息
        gson = new GsonBuilder()
                .registerTypeAdapter(BaseItem.class, new BaseItemTypeAdapter())
                .create();
        // 修复：添加异常捕获，加载失败时初始化空列表
        try {
            loadData();
        } catch (Exception e) {
            e.printStackTrace();
            // 加载失败时清空旧数据，初始化空列表
            allItems = new ArrayList<>();
            saveData(); // 覆盖错误数据
        }
    }

    public static synchronized DataManager getInstance(Context context) {
        if (instance == null) {
            instance = new DataManager(context.getApplicationContext());
        }
        return instance;
    }

    private void loadData() {
        String json = sharedPreferences.getString(KEY_ALL_ITEMS, null);
        Type type = new TypeToken<ArrayList<BaseItem>>() {}.getType();
        // 空值保护：json为空时初始化空列表
        if (json == null || json.isEmpty()) {
            allItems = new ArrayList<>();
        } else {
            allItems = gson.fromJson(json, type);
            // 二次校验：防止反序列化返回null
            if (allItems == null) {
                allItems = new ArrayList<>();
            }
        }
    }

    public void saveData() {
        try {
            String json = gson.toJson(allItems);
            sharedPreferences.edit().putString(KEY_ALL_ITEMS, json).apply();
        } catch (Exception e) {
            e.printStackTrace();
            // 核心修复：使用保存的appContext显示Toast
            Toast.makeText(appContext, "数据保存失败", Toast.LENGTH_SHORT).show();
        }
    }

    public void addItem(BaseItem item) {
        if (item == null) return; // 空值保护
        if (item.getId() == null || item.getId().isEmpty()) {
            item.setId(UUID.randomUUID().toString());
        }
        allItems.add(item);
        saveData();
    }

    public void deleteItem(String id) {
        if (id == null || id.isEmpty()) return; // 空值保护
        for (int i = 0; i < allItems.size(); i++) {
            if (allItems.get(i).getId().equals(id)) {
                allItems.remove(i);
                saveData();
                break;
            }
        }
    }

    public void updateItem(BaseItem updatedItem) {
        if (updatedItem == null || updatedItem.getId() == null) return; // 空值保护
        for (int i = 0; i < allItems.size(); i++) {
            if (allItems.get(i).getId().equals(updatedItem.getId())) {
                allItems.set(i, updatedItem);
                saveData();
                break;
            }
        }
    }

    public List<BaseItem> searchItems(String keyword) {
        List<BaseItem> result = new ArrayList<>();
        if (keyword == null) keyword = ""; // 空值保护
        for (BaseItem item : allItems) {
            if ((item.getName() != null && item.getName().contains(keyword)) ||
                    (item.getTags() != null && item.getTags().contains(keyword))) {
                result.add(item);
            }
        }
        return result;
    }

    public List<BaseItem> getAllItems() {
        return new ArrayList<>(allItems); // 返回副本，防止外部修改
    }

    public BaseItem getItemById(String id) {
        if (id == null || id.isEmpty()) return null; // 空值保护
        for (BaseItem item : allItems) {
            if (item.getId().equals(id)) {
                return item;
            }
        }
        return null;
    }

    public List<BaseItem> getItemsByType(String type) {
        List<BaseItem> result = new ArrayList<>();
        if (type == null) return result; // 空值保护
        for (BaseItem item : allItems) {
            if (type.equals(item.getType())) {
                result.add(item);
            }
        }
        return result;
    }
}