package com.example.inventorydata;

// 物品条目：从属容器 + 数量 + 保质期
public class Item extends BaseItem {
    private String belongContainerId; // 从属容器ID
    private int quantity;              // 物品数量
    private String expirationDate;     // 保质期（格式：yyyy-MM-dd）

    // 空构造方法（必须保留，Gson反序列化需要）
    public Item() {
        super();
    }

    // 带参构造方法
    public Item(String id, String name, String belongContainerId, int quantity, String expirationDate) {
        super(id, name);
        this.belongContainerId = belongContainerId;
        this.quantity = quantity;
        this.expirationDate = expirationDate;
    }

    @Override
    public String getType() {
        return "物品";
    }

    // Getter & Setter
    public String getBelongContainerId() {
        return belongContainerId;
    }

    public void setBelongContainerId(String belongContainerId) {
        this.belongContainerId = belongContainerId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }
}