package com.example.inventorydata;

public abstract class BaseItem {
    private String id;
    private String name;
    private String imagePath; // 图片路径
    private String tags;      // 标签
    private String remark;    // 备注

    // 必须保留空构造方法（Gson反序列化需要）
    public BaseItem() {}

    public BaseItem(String id, String name) {
        this.id = id;
        this.name = name;
    }

    // 抽象方法：获取条目类型
    public abstract String getType();

    // Getter & Setter（确保imagePath的方法完整）
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}