package com.example.inventorydata;

public class LocationItem extends BaseItem {
    private String address;

    // 空构造方法（必须保留）
    public LocationItem() {
        super();
    }

    public LocationItem(String id, String name, String address) {
        super(id, name);
        this.address = address;
    }

    @Override
    public String getType() {
        return "地点";
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}