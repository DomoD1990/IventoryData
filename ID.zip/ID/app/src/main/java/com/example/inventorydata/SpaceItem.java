package com.example.inventorydata;

// 空间条目：从属地点
public class SpaceItem extends BaseItem {
    private String belongLocationId; // 从属地点ID

    // 空构造方法（必须保留，Gson反序列化需要）
    public SpaceItem() {
        super();
    }

    // 带参构造方法
    public SpaceItem(String id, String name, String belongLocationId) {
        super(id, name);
        this.belongLocationId = belongLocationId;
    }

    @Override
    public String getType() {
        return "空间";
    }

    // Getter & Setter
    public String getBelongLocationId() {
        return belongLocationId;
    }

    public void setBelongLocationId(String belongLocationId) {
        this.belongLocationId = belongLocationId;
    }
}